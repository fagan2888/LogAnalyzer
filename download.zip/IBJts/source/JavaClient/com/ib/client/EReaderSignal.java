package com.ib.client;

public interface EReaderSignal {
	void issueSignal();
    void waitForSignal();
}
